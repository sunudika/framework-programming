<div class="container mt-5">
    <div class="jumbotron">
    <h1 class="display-4">Selamat Datang!!</h1>
    <p class="lead">Website ini dibuat untuk memenuhi tugas <strong>Pemrograman Framework</strong></p>
    <hr class="my-4">
    <p>Silahkan Menuju ke Bagian Pengelolaan Data</p>
    <a class="btn btn-primary btn-lg" href="<?php echo base_url('airports'); ?>" role="button">Kelola Data</a>
    </div>
</div>