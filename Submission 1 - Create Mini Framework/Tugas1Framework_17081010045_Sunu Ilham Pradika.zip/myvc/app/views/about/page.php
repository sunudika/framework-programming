
    <h1>My Page</h1>
    <p>Anda sekarang berada di Views about/page.php</p>
    <a href="../about">Akses halaman about/index.php</a>
    <br><br>
    <a href="../">Kembali ke halaman utama home/index.php</a>
