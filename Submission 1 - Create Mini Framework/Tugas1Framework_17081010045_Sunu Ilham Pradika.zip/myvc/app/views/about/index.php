
    <h1>About Me</h1>
    <p>Halo, nama saya <?= $data['nama']; ?>, umur saya <?= $data['umur'];  ?> tahun, saya adalah seorang <?= $data['pekerjaan']; ?>.</p>

    <p>Anda sekarang berada di Views about/index.php</p>
    <a href="about/page">Akses halaman about/page.php</a>
    <br><br>
    <a href="home">Kembali ke halaman utama home/index.php</a>